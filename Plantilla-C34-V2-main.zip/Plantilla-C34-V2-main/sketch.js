
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var gun, gunImg;
var bull, bulletImg
var bullseye, bullseyeImg;
var background, backgroundImg;
var numberOfBullets = 20;
var score = 0;  
var PBullets = [];

function preload (){
  backgroundImg = loadImage("Background.jpeg");
  bullseyeImg = loadImage("bullseye.png");
  bulletImg = loadImage("bullet.png");
}

function setup() {
  createCanvas(windowWidth,windowHeight);

  engine = Engine.create();
  world = engine.world;

  gun = createSprite(width - 700,height/2,20,20)
  gun.addImage("gun.png");

  board1 = new Board(width - 250, 330, 50, 200);
  board2 = new Board(width - 300, height - 300, 50, 200);

}


function draw() 
{
  background(51);
  image(backgroundImg,0,0,width,height);
  Engine.update(engine);

  for (var i = 0; i < PBullets.length; i++) {
    if (PBullets[i] !== undefined) {
      PBullets[i].display();

      var board1Collision = Matter.SAT.collides(
        board1.body,
        PBullets[i].body
      );

      var board2Collision = Matter.SAT.collides(
        board2.body,
        PBullets[i].body
      );

      if (board1Collision.collided || board2Collision.collided) {
        score += 5;
      } 

      if (posX > width || posY > height) {
        if (!PBullets[i].isRemoved) {
          PBullets[i].remove(i);
        } else {
          PBullets[i].trajectory = [];
        }
      }
    }
  }


  //Título
  fill("#FFFF");
  textAlign("center");
  textSize(40);
  text("Shootin of guns", width / 2, 100);

  //Puntuación
  fill("#FFFF");
  textAlign("center");
  textSize(30);
  text("Score " + score, width - 200, 100);

  //Conteo de flechas
  fill("#FFFF");
  textAlign("center");
  textSize(30);
  text("Bullets: " + numberOfBullets, 200, 100);

  drawSprites();
}

function keyPressed() {
  if (keyCode === 32) {
    if (numberOfBullets > 0) {
      var posX = gun.body.position.x;
      var posY = gun.body.position.y;
      var angle = gun.body.angle;

      var bullet = new Bullet(posX, posY, 100, 10, angle);

      bullet.trajectory = [];
      Matter.Body.setAngle(bullet.body, angle);
      PBullets.push(bullet);
      numberOfBullets -= 1;
    }
  }
}

function keyReleased() {
  if (keyCode === 32) {
    if (PBullets.length) {
      var angle = gun.body.angle;
      PBullets[PBullets.length - 1].shoot(angle);
    }
  }
}

function gameOver() {
  swal(
    {
      title: `¡Game Over!`,
      imageUrl:
        "https://raw.githubusercontent.com/vishalgaddam873/PiratesInvision/main/assets/board.png",
      imageSize: "150x150",
      confirmButtonText: "Play again"
    },
    function(isConfirm) {
      if (isConfirm) {
        location.reload();
      }
    }
  );
}